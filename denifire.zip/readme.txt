=== Denifire Theme ===
Contributors: wordpressdotorg
Requires at least: 4.9.6
Tested up to: WordPress 5.2
Requires PHP: 7.0
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Our 2019 default theme is designed to show off the power of the block editor.

== Description ==
Denifire Theme - Work in Progress

== Changelog ==

= 1.1.1 =
* Released: Mar 9, 2020

= 1.1.0 =
* Released: Jan 1, 2020

= 1.0.0 =
* Released: December 6, 2019
Initial release

== Resources ==
* Underscores, © 2012-2018 Automattic, Inc., GNU GPL v2 or later

